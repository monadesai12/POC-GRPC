const PROTO_PATH="./proto/customers.proto";

var grpc = require("grpc");
var protoloader = require("@grpc/proto-loader");

var packageDefination = protoloader.loadSync(PROTO_PATH ,{
    keepCase: true,
    longs: String,
    enums: String,
    arrays: true
});

var customerProto = grpc.loadPackageDefinition(packageDefination);
const { v4: uuidv4 } = require("uuid");

const server = new grpc.Server();