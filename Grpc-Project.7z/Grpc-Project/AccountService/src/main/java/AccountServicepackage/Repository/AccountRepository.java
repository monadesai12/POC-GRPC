package AccountServicepackage.Repository;

import AccountServicepackage.Entity.AccountEntity;
import org.checkerframework.checker.units.qual.A;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Map;

public interface AccountRepository  extends JpaRepository<AccountEntity, Integer> {

    public List<AccountEntity> findByAccountType(String AccountType);


}
