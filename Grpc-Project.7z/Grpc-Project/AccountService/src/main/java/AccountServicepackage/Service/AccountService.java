package AccountServicepackage.Service;

import AccountServicepackage.Entity.AccountEntity;
import AccountServicepackage.Repository.AccountRepository;
import com.account.AccountserviceGrpc;
import com.account.*;
import io.grpc.stub.StreamObserver;
import net.devh.boot.grpc.server.service.GrpcService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@GrpcService
public class AccountService extends AccountserviceGrpc.AccountserviceImplBase {

    @Autowired
    private AccountRepository accountRepository;



    @Override
    public void getAccount(getAccountRequest request, StreamObserver<getAccountResponse> responseObserver) {
        System.out.println("Account get:");
        getAccountResponse.Builder builder = getAccountResponse.newBuilder().setAccount(
                Account.newBuilder().setDescription("Account Not Found")
        );
        int ID=request.getAccountId();
        accountRepository.findById(ID).ifPresent(
                account -> {
                    builder.setAccount(
                            Account.newBuilder().setAccountId(account.getAccount_id())
                                    .setAccountCode(account.getAccount_code())
                                    .setAccountType(account.getAccountType())
                                    .setDescription(account.getDescription())
                                    .build());
                }
        );
        getAccountResponse response = builder.build();
        responseObserver.onNext(response);
        responseObserver.onCompleted();
        System.out.println("Account Found");
    }

    @Override
    public void addAccount(CreateAccountRequest request, StreamObserver<CreateAccountResponse> responseObserver) {
        System.out.println("Account Creation");
        Account account= request.getAccount();
        AccountEntity accountEntity = AccountEntity.builder().account_code(account.getAccountCode())
                .accountType(account.getAccountType())
                .description(account.getDescription()).build();

        accountRepository.save(accountEntity);
        CreateAccountResponse response =CreateAccountResponse.newBuilder().setMsg("Account Created").build();
        responseObserver.onNext(response);
        responseObserver.onCompleted();
        System.out.println("Account Created");



    }

    @Override
    public void deleteAccount(DeleteAccountRequest request, StreamObserver<DeleteAccountResponse> responseObserver) {
        System.out.println("Account Deletion:");
        DeleteAccountResponse.Builder builder = DeleteAccountResponse.newBuilder();
        int ID=request.getAccountId();
        accountRepository.findById(ID).ifPresent(
                accountEntity -> accountRepository.delete(accountEntity)
        );
        DeleteAccountResponse response =DeleteAccountResponse.newBuilder().setMsg("Account Deleted").build();
        responseObserver.onNext(response);
        responseObserver.onCompleted();
        System.out.println("Account deleted.");
    }

    @Override
    public void modifyAccount(modifyAccountRequest request, StreamObserver<modifyAccountResponse> responseObserver) {
        System.out.println("Account Updation: ");
        modifyAccountResponse.Builder builder = modifyAccountResponse.newBuilder();
        int ID = request.getAccount().getAccountId();
        Account requestAccount = request.getAccount();
        AccountEntity account = AccountEntity.builder()
                .account_id(requestAccount.getAccountId())
                .account_code(requestAccount.getAccountCode())
                .accountType(requestAccount.getAccountType())
                .description(requestAccount.getDescription())
                .build();
        accountRepository.findById(ID).ifPresent(
                accountEntity -> { accountRepository.save(account);
                    builder.setAccount(
                            Account.newBuilder().setAccountId(account.getAccount_id())
                                    .setAccountCode(account.getAccount_code())
                                    .setAccountType(account.getAccountType())
                                    .setDescription(account.getDescription())
                                    .build()
                    );
                }
        );
        responseObserver.onNext(builder.build());
        responseObserver.onCompleted();
        System.out.println("Account Updated");

    }


    @Override
    public void getAccountType(AccountRequest request, StreamObserver<AccountTypeResponse> responseObserver) {
        String accountType = request.getAccountType();
        List<Integer> accountIds = accountRepository.findByAccountType(accountType).stream()
                .map(accountEntity -> accountEntity.getAccount_id()).collect(Collectors.toList());

        responseObserver.onNext(AccountTypeResponse.newBuilder().addAllAccountId(accountIds).build());
        responseObserver.onCompleted();

    }

    @Override
    public void getAccountIdSameType(AccountIdRequest request, StreamObserver<AccountTypeResponse> responseObserver) {
        int accountId = request.getAccountId();
        AccountEntity account = accountRepository.findById(accountId).get();
        List<Integer> accountIds = accountRepository.findByAccountType(account.getAccountType()).stream()
                .map(accountEntity -> accountEntity.getAccount_id()).collect(Collectors.toList());

        responseObserver.onNext(AccountTypeResponse.newBuilder().addAllAccountId(accountIds).build());
        responseObserver.onCompleted();

    }

    @Override
    public void getAccountCode(AccountRequest request, StreamObserver<AccountCodeResponse> responseObserver) {

        String accountType = request.getAccountType();
        accountRepository.findByAccountType(accountType);
        List<Integer> accountCodes = accountRepository.findByAccountType(accountType).stream()
                .map(accountEntity -> accountEntity.getAccount_code()).collect(Collectors.toList());

        responseObserver.onNext(AccountCodeResponse.newBuilder().addAllAccountCode(accountCodes).build());
        responseObserver.onCompleted();







    }
}
