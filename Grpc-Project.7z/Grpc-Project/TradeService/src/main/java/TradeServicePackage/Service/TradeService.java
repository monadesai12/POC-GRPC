package TradeServicePackage.Service;

import TradeServicePackage.Entity.TradeEntity;
import TradeServicePackage.Repository.TradeRepository;
import com.account.*;
import com.account.TradeServiceGrpc;
import io.grpc.stub.StreamObserver;
import net.devh.boot.grpc.client.inject.GrpcClient;
import net.devh.boot.grpc.server.service.GrpcService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@GrpcService
public class TradeService extends TradeServiceGrpc.TradeServiceImplBase {


    @GrpcClient("account-service")
    private AccountserviceGrpc.AccountserviceBlockingStub accountStub;

    @Autowired
    private TradeRepository tradeRepository;

    @Override
    public void getTrade(GetTradeRequest request, StreamObserver<GetTradeResponse> responseObserver) {
        GetTradeResponse.Builder builder = GetTradeResponse.newBuilder();
        int No = request.getTradeNo();
        tradeRepository.findById(No).ifPresent(
                trade -> builder.setTrade(
                        Trade.newBuilder().setTradeNo(trade.getTrade_no())
                                .setTradeQuantity(trade.getTrade_quantity())
                                .setTradeRate(trade.getTrade_rate())
                                .build())
        );
        GetTradeResponse response = builder.build();
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void addTrade(CreateTradeRequest request, StreamObserver<CreateTradeResponse> responseObserver) {
        System.out.println("Trade Creation");
        Trade trade= request.getTrade();
        TradeEntity tradeEntity= TradeEntity.builder().trade_quantity(trade.getTradeQuantity())
                .trade_rate(trade.getTradeRate())
                .build();
        tradeRepository.save(tradeEntity);
        CreateTradeResponse response =CreateTradeResponse.newBuilder().setMsg("Trade Created").build();
        responseObserver.onNext(response);
        responseObserver.onCompleted();
        System.out.println("Trade created");

    }

    @Override
    public void deleteTrade(DeleteTradeRequest request, StreamObserver<DeleteTradeResponse> responseObserver) {
        int No =request.getTradeNo();
        tradeRepository.findById(No).ifPresent(
                tradeEntity -> {
                    tradeRepository.delete(tradeEntity);
                }
        );
        DeleteTradeResponse response=DeleteTradeResponse.newBuilder().setMsg("Trade Deletd").build();
        responseObserver.onNext(response);
        responseObserver.onCompleted();
        System.out.println("Trade Deleted");
    }

    @Override
    public void modifyTrade(ModifyTradeRequest request, StreamObserver<ModifyTradeResponse> responseObserver) {
        System.out.println("Trade Updation: ");
        ModifyTradeResponse.Builder builder = ModifyTradeResponse.newBuilder();
        int No =request.getTrade().getTradeNo();
        Trade requestTrade = request.getTrade();
        TradeEntity trade = TradeEntity.builder().trade_no(requestTrade.getTradeNo())
                .trade_rate(requestTrade.getTradeRate())
                .trade_quantity(requestTrade.getTradeQuantity())
                .build();
        tradeRepository.findById(No).ifPresent(
                tradeEntity1 -> { tradeRepository.save(trade);
                    builder.setTrade(
                            Trade.newBuilder().setTradeNo(trade.getTrade_no())
                                    .setTradeRate(trade.getTrade_rate())
                                    .setTradeQuantity(trade.getTrade_quantity())
                                    .build()
                    );
                }
        );
        responseObserver.onNext(builder.build());
        responseObserver.onCompleted();
        System.out.println("Trade Updated");

    }




    @Override
    public void getTradeByAccountId(GetTradeSearchRequest request, StreamObserver<MultipleTrades> responseObserver) {

        int accountId = request.getAccountId();
        AccountIdRequest accountIdRequest = AccountIdRequest.newBuilder().setAccountId(accountId).build();
        List<Integer> accountIdList = this.accountStub.getAccountIdSameType(accountIdRequest).getAccountIdList();
        List<TradeEntity> collect = accountIdList.stream().map(id -> tradeRepository.findByAccountId(id).stream().collect(Collectors.toList()))
                .flatMap(Collection::stream).collect(Collectors.toList());
        collect.forEach(System.out::println);

        // get all details
        List<Trade> responseTrades = collect.stream().map(
                tradeEntity -> Trade.newBuilder().setTradeRate(tradeEntity.getTrade_rate())
                        .setTradeNo(tradeEntity.getTrade_no())
                        .setTradeQuantity(tradeEntity.getTrade_quantity())
                        .build())
                .collect(Collectors.toList());

        MultipleTrades response = MultipleTrades.newBuilder().addAllTrades(responseTrades).build();
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void getTradeByAccountType(GetTrade request, StreamObserver<MultipleTrades> responseObserver) {

        String accountType = request.getAccountType();
        AccountTypeResponse accountTypeResponse = this.accountStub.getAccountType(AccountRequest.newBuilder().setAccountType(accountType).build());

        List<Integer> accountIdList = accountTypeResponse.getAccountIdList();

        List<TradeEntity> collect = accountIdList.stream().map(id -> tradeRepository.findByAccountId(id).stream().collect(Collectors.toList()))
                .flatMap(Collection::stream).collect(Collectors.toList());
        collect.forEach(System.out::println);

        // get all details
        List<Trade> responseTrades = collect.stream().map(
                        tradeEntity -> Trade.newBuilder().setTradeRate(tradeEntity.getTrade_rate())
                                .setTradeNo(tradeEntity.getTrade_no())
                                .setTradeQuantity(tradeEntity.getTrade_quantity())
                                .build())
                .collect(Collectors.toList());

        MultipleTrades response = MultipleTrades.newBuilder().addAllTrades(responseTrades).build();
        responseObserver.onNext(response);
        responseObserver.onCompleted();


    }
}
