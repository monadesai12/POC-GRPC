package TradeServicePackage.Entity;

import com.account.Account;
import jdk.jfr.Unsigned;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.checkerframework.common.aliasing.qual.Unique;

import javax.persistence.*;
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="trade_table")
public class TradeEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Unique
    private int trade_no;
    private int trade_quantity;
    private int trade_rate;
    private int accountId;



    public int getTrade_no() {
        return trade_no;
    }

    public void setTrade_no(int trade_no) {
        this.trade_no = trade_no;
    }

    public int getTrade_quantity() {
        return trade_quantity;
    }

    public void setTrade_quantity(int trade_quantity) {
        this.trade_quantity = trade_quantity;
    }

    public int getTrade_rate() {
        return trade_rate;
    }

    public void setTrade_rate(int trade_rate) {
        this.trade_rate = trade_rate;
    }

    public int getAccount_id() {
        return accountId;
    }

    public void setAccount_id(int account_id) {
        this.accountId = account_id;
    }


}

